const CaroselData = [
  {
    coverImageUri:
      "https://vietflower.vn/wp-content/uploads/2017/02/hoa-lan-Mokara..jpg",
  },
  {
    coverImageUri:
      "https://www.cleanipedia.com/images/5iwkm8ckyw6v/JS7hhhpeYn3BkjsmGfuvF/c1f260a10def117b907af25563fef797/cGluay1waGFsYWVub3BzaXMtb3JjaGlkLWZsb3dlci5qcGc/990w-660h/lan-h%E1%BB%93-%C4%91i%E1%BB%87p.jpg",
  },
  {
    coverImageUri:
      "https://www.theflowerexpert.com/wp-content/uploads/2022/11/Orchid-Cattleya.jpg",
  },
  {
    coverImageUri:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMG7D7XLff_VsMmhW0zNn7HtV089U9_DhF3fPEWP0ujCyjSxm5QrORUYXgLUCge1SwcYU&usqp=CAU",
  },
  {
    coverImageUri:
      "https://hoalanhuyanh.com/userfiles/image/blog-huy-anh/2021/phi-diep/hoa-dep/bet.jpg",
  },
  {
    coverImageUri: "https://i.ytimg.com/vi/J_YjahLFgDo/maxresdefault.jpg",
  },
];
export default CaroselData;
